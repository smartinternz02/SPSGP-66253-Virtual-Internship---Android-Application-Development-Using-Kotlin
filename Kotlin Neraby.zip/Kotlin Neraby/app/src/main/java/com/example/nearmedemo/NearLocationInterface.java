package com.example.nearmedemo;

public interface NearLocationInterface {

    void onSaveClick(GooglePlaceModel googlePlaceModel);

    void onDirectionClick(GooglePlaceModel googlePlaceModel);
}
